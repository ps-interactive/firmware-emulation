#!/bin/sh

ov7740 -a 13 -d 00
ov7740 -a 0f -d 00
ov7740 -a 10 -d FC
ov7740 -a 00 -d 3f
ov7740 -a 01 -d 59
ov7740 -a 02 -d 59

